
# Sistema Django - BANINI

## Como rodar o projeto:

1. Vá até a pasta do projeto:
   cd banini_django_real

2. Crie um ambiente virtual (opcional, mas recomendado):
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate

3. Instale o Django:
   pip install django

4. Aplique as migrações iniciais:
   python manage.py migrate

5. Rode o servidor:
   python manage.py runserver

6. Acesse no navegador:
   http://127.0.0.1:8000/

Você verá a mensagem: "Sistema BANINI funcionando! 🚀"
