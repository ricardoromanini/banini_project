
from django.http import HttpResponse

def home(request):
    return HttpResponse("<h1>Sistema BANINI funcionando! 🚀</h1>")
